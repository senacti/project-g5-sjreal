/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "sucursales")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sucursales.findAll", query = "SELECT s FROM Sucursales s"),
    @NamedQuery(name = "Sucursales.findByIdSucursal", query = "SELECT s FROM Sucursales s WHERE s.idSucursal = :idSucursal"),
    @NamedQuery(name = "Sucursales.findByNITsucursal", query = "SELECT s FROM Sucursales s WHERE s.nITsucursal = :nITsucursal"),
    @NamedQuery(name = "Sucursales.findByNombreSucursal", query = "SELECT s FROM Sucursales s WHERE s.nombreSucursal = :nombreSucursal"),
    @NamedQuery(name = "Sucursales.findByDepartamentoSucursal", query = "SELECT s FROM Sucursales s WHERE s.departamentoSucursal = :departamentoSucursal"),
    @NamedQuery(name = "Sucursales.findByCuidadSucursal", query = "SELECT s FROM Sucursales s WHERE s.cuidadSucursal = :cuidadSucursal"),
    @NamedQuery(name = "Sucursales.findByCalleSucursal", query = "SELECT s FROM Sucursales s WHERE s.calleSucursal = :calleSucursal"),
    @NamedQuery(name = "Sucursales.findByCarreraSucursal", query = "SELECT s FROM Sucursales s WHERE s.carreraSucursal = :carreraSucursal"),
    @NamedQuery(name = "Sucursales.findByTelefonoSucursal", query = "SELECT s FROM Sucursales s WHERE s.telefonoSucursal = :telefonoSucursal"),
    @NamedQuery(name = "Sucursales.findByCorreoSucursal", query = "SELECT s FROM Sucursales s WHERE s.correoSucursal = :correoSucursal")})
public class Sucursales implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_sucursal")
    private Integer idSucursal;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "NIT_sucursal")
    private String nITsucursal;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nombre_sucursal")
    private String nombreSucursal;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 24)
    @Column(name = "departamento_sucursal")
    private String departamentoSucursal;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "cuidad_sucursal")
    private String cuidadSucursal;
    @Basic(optional = false)
    @NotNull
    @Column(name = "calle_sucursal")
    private int calleSucursal;
    @Basic(optional = false)
    @NotNull
    @Column(name = "carrera_sucursal")
    private int carreraSucursal;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "telefono_sucursal")
    private String telefonoSucursal;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 80)
    @Column(name = "correo_sucursal")
    private String correoSucursal;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "habitacionIdSucursal", fetch = FetchType.LAZY)
    private List<Habitaciones> habitacionesList;
    @JoinColumn(name = "usuario_id_sucursal", referencedColumnName = "personas_id_persona")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Usuarios usuarioIdSucursal;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inventarioSucersalIdSucursal", fetch = FetchType.LAZY)
    private List<Iventarios> iventariosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sucursalesHasProveedoresIdSucursal", fetch = FetchType.LAZY)
    private List<SucursalesHasProveedores> sucursalesHasProveedoresList;

    public Sucursales() {
    }

    public Sucursales(Integer idSucursal) {
        this.idSucursal = idSucursal;
    }

    public Sucursales(Integer idSucursal, String nITsucursal, String nombreSucursal, String departamentoSucursal, String cuidadSucursal, int calleSucursal, int carreraSucursal, String telefonoSucursal, String correoSucursal) {
        this.idSucursal = idSucursal;
        this.nITsucursal = nITsucursal;
        this.nombreSucursal = nombreSucursal;
        this.departamentoSucursal = departamentoSucursal;
        this.cuidadSucursal = cuidadSucursal;
        this.calleSucursal = calleSucursal;
        this.carreraSucursal = carreraSucursal;
        this.telefonoSucursal = telefonoSucursal;
        this.correoSucursal = correoSucursal;
    }

    public Integer getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(Integer idSucursal) {
        this.idSucursal = idSucursal;
    }

    public String getNITsucursal() {
        return nITsucursal;
    }

    public void setNITsucursal(String nITsucursal) {
        this.nITsucursal = nITsucursal;
    }

    public String getNombreSucursal() {
        return nombreSucursal;
    }

    public void setNombreSucursal(String nombreSucursal) {
        this.nombreSucursal = nombreSucursal;
    }

    public String getDepartamentoSucursal() {
        return departamentoSucursal;
    }

    public void setDepartamentoSucursal(String departamentoSucursal) {
        this.departamentoSucursal = departamentoSucursal;
    }

    public String getCuidadSucursal() {
        return cuidadSucursal;
    }

    public void setCuidadSucursal(String cuidadSucursal) {
        this.cuidadSucursal = cuidadSucursal;
    }

    public int getCalleSucursal() {
        return calleSucursal;
    }

    public void setCalleSucursal(int calleSucursal) {
        this.calleSucursal = calleSucursal;
    }

    public int getCarreraSucursal() {
        return carreraSucursal;
    }

    public void setCarreraSucursal(int carreraSucursal) {
        this.carreraSucursal = carreraSucursal;
    }

    public String getTelefonoSucursal() {
        return telefonoSucursal;
    }

    public void setTelefonoSucursal(String telefonoSucursal) {
        this.telefonoSucursal = telefonoSucursal;
    }

    public String getCorreoSucursal() {
        return correoSucursal;
    }

    public void setCorreoSucursal(String correoSucursal) {
        this.correoSucursal = correoSucursal;
    }

    @XmlTransient
    public List<Habitaciones> getHabitacionesList() {
        return habitacionesList;
    }

    public void setHabitacionesList(List<Habitaciones> habitacionesList) {
        this.habitacionesList = habitacionesList;
    }

    public Usuarios getUsuarioIdSucursal() {
        return usuarioIdSucursal;
    }

    public void setUsuarioIdSucursal(Usuarios usuarioIdSucursal) {
        this.usuarioIdSucursal = usuarioIdSucursal;
    }

    @XmlTransient
    public List<Iventarios> getIventariosList() {
        return iventariosList;
    }

    public void setIventariosList(List<Iventarios> iventariosList) {
        this.iventariosList = iventariosList;
    }

    @XmlTransient
    public List<SucursalesHasProveedores> getSucursalesHasProveedoresList() {
        return sucursalesHasProveedoresList;
    }

    public void setSucursalesHasProveedoresList(List<SucursalesHasProveedores> sucursalesHasProveedoresList) {
        this.sucursalesHasProveedoresList = sucursalesHasProveedoresList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSucursal != null ? idSucursal.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sucursales)) {
            return false;
        }
        Sucursales other = (Sucursales) object;
        if ((this.idSucursal == null && other.idSucursal != null) || (this.idSucursal != null && !this.idSucursal.equals(other.idSucursal))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Sucursales[ idSucursal=" + idSucursal + " ]";
    }
    
}

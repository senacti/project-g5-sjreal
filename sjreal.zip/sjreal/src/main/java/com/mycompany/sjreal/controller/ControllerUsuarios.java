/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.sjreal.controller;

import com.mycompany.sjreal.entities.Usuarios;
import com.mycompany.sjreal.model.UsuariosFacadeLocal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author usuario
 */
@Named(value = "controllerUsuarios")
@SessionScoped
public class ControllerUsuarios implements Serializable {

    /**
     * Creates a new instance of ControllerUsuarios
     */
    private Usuarios usuario = new Usuarios();
    @EJB
    private UsuariosFacadeLocal uf1;
    private FacesContext contexto;
    private FacesMessage fm;
    
    public ControllerUsuarios() {
    }

    public Usuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuarios usuario) {
        this.usuario = usuario;
    }
    
    public void crearUsuario() {
        contexto = FacesContext.getCurrentInstance();
        try {
            this.uf1.create(usuario);
            fm = new FacesMessage(FacesMessage.SEVERITY_INFO, "Se creó el usuario", "MSG_INFO");
        } catch(Exception e) {
            fm = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error al crear usuario", "MSG_ERROR");
        }
        contexto.addMessage(null, fm);
    }
    
    
    public List<Usuarios> listarUsuarios() {
        try {
            return this.uf1.findAll();
        } catch (Exception e) {
            
        }
        return null;
    }
    
}

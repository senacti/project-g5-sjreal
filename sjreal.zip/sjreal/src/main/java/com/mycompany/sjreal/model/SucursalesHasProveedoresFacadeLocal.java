/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sjreal.model;

import com.mycompany.sjreal.entities.SucursalesHasProveedores;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author usuario
 */
@Local
public interface SucursalesHasProveedoresFacadeLocal {

    void create(SucursalesHasProveedores sucursalesHasProveedores);

    void edit(SucursalesHasProveedores sucursalesHasProveedores);

    void remove(SucursalesHasProveedores sucursalesHasProveedores);

    SucursalesHasProveedores find(Object id);

    List<SucursalesHasProveedores> findAll();

    List<SucursalesHasProveedores> findRange(int[] range);

    int count();
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "roles_has_usuarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "RolesHasUsuarios.findAll", query = "SELECT r FROM RolesHasUsuarios r"),
    @NamedQuery(name = "RolesHasUsuarios.findByIdRolUsuario", query = "SELECT r FROM RolesHasUsuarios r WHERE r.idRolUsuario = :idRolUsuario")})
public class RolesHasUsuarios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_rol_usuario")
    private Integer idRolUsuario;
    @JoinColumn(name = "roles_id_rol", referencedColumnName = "id_rol")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Roles rolesIdRol;
    @JoinColumn(name = "usuarios_personas_id_persona", referencedColumnName = "personas_id_persona")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Usuarios usuariosPersonasIdPersona;

    public RolesHasUsuarios() {
    }

    public RolesHasUsuarios(Integer idRolUsuario) {
        this.idRolUsuario = idRolUsuario;
    }

    public Integer getIdRolUsuario() {
        return idRolUsuario;
    }

    public void setIdRolUsuario(Integer idRolUsuario) {
        this.idRolUsuario = idRolUsuario;
    }

    public Roles getRolesIdRol() {
        return rolesIdRol;
    }

    public void setRolesIdRol(Roles rolesIdRol) {
        this.rolesIdRol = rolesIdRol;
    }

    public Usuarios getUsuariosPersonasIdPersona() {
        return usuariosPersonasIdPersona;
    }

    public void setUsuariosPersonasIdPersona(Usuarios usuariosPersonasIdPersona) {
        this.usuariosPersonasIdPersona = usuariosPersonasIdPersona;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRolUsuario != null ? idRolUsuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RolesHasUsuarios)) {
            return false;
        }
        RolesHasUsuarios other = (RolesHasUsuarios) object;
        if ((this.idRolUsuario == null && other.idRolUsuario != null) || (this.idRolUsuario != null && !this.idRolUsuario.equals(other.idRolUsuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.RolesHasUsuarios[ idRolUsuario=" + idRolUsuario + " ]";
    }
    
}

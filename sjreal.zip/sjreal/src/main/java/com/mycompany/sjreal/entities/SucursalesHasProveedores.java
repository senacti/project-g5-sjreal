/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "sucursales_has_proveedores")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SucursalesHasProveedores.findAll", query = "SELECT s FROM SucursalesHasProveedores s"),
    @NamedQuery(name = "SucursalesHasProveedores.findByIdSucursalesHasProveedores", query = "SELECT s FROM SucursalesHasProveedores s WHERE s.idSucursalesHasProveedores = :idSucursalesHasProveedores"),
    @NamedQuery(name = "SucursalesHasProveedores.findByFechaInicioActividades", query = "SELECT s FROM SucursalesHasProveedores s WHERE s.fechaInicioActividades = :fechaInicioActividades"),
    @NamedQuery(name = "SucursalesHasProveedores.findByAntiguedadActividades", query = "SELECT s FROM SucursalesHasProveedores s WHERE s.antiguedadActividades = :antiguedadActividades")})
public class SucursalesHasProveedores implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_sucursales_has_proveedores")
    private Integer idSucursalesHasProveedores;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_inicio_actividades")
    @Temporal(TemporalType.DATE)
    private Date fechaInicioActividades;
    @Basic(optional = false)
    @NotNull
    @Column(name = "antiguedad_actividades")
    private int antiguedadActividades;
    @JoinColumn(name = "sucursales_has_proveedores_id_sucursal", referencedColumnName = "id_sucursal")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Sucursales sucursalesHasProveedoresIdSucursal;
    @JoinColumn(name = "proveedores_id_proveedor", referencedColumnName = "id_proveedor")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Proveedores proveedoresIdProveedor;

    public SucursalesHasProveedores() {
    }

    public SucursalesHasProveedores(Integer idSucursalesHasProveedores) {
        this.idSucursalesHasProveedores = idSucursalesHasProveedores;
    }

    public SucursalesHasProveedores(Integer idSucursalesHasProveedores, Date fechaInicioActividades, int antiguedadActividades) {
        this.idSucursalesHasProveedores = idSucursalesHasProveedores;
        this.fechaInicioActividades = fechaInicioActividades;
        this.antiguedadActividades = antiguedadActividades;
    }

    public Integer getIdSucursalesHasProveedores() {
        return idSucursalesHasProveedores;
    }

    public void setIdSucursalesHasProveedores(Integer idSucursalesHasProveedores) {
        this.idSucursalesHasProveedores = idSucursalesHasProveedores;
    }

    public Date getFechaInicioActividades() {
        return fechaInicioActividades;
    }

    public void setFechaInicioActividades(Date fechaInicioActividades) {
        this.fechaInicioActividades = fechaInicioActividades;
    }

    public int getAntiguedadActividades() {
        return antiguedadActividades;
    }

    public void setAntiguedadActividades(int antiguedadActividades) {
        this.antiguedadActividades = antiguedadActividades;
    }

    public Sucursales getSucursalesHasProveedoresIdSucursal() {
        return sucursalesHasProveedoresIdSucursal;
    }

    public void setSucursalesHasProveedoresIdSucursal(Sucursales sucursalesHasProveedoresIdSucursal) {
        this.sucursalesHasProveedoresIdSucursal = sucursalesHasProveedoresIdSucursal;
    }

    public Proveedores getProveedoresIdProveedor() {
        return proveedoresIdProveedor;
    }

    public void setProveedoresIdProveedor(Proveedores proveedoresIdProveedor) {
        this.proveedoresIdProveedor = proveedoresIdProveedor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSucursalesHasProveedores != null ? idSucursalesHasProveedores.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SucursalesHasProveedores)) {
            return false;
        }
        SucursalesHasProveedores other = (SucursalesHasProveedores) object;
        if ((this.idSucursalesHasProveedores == null && other.idSucursalesHasProveedores != null) || (this.idSucursalesHasProveedores != null && !this.idSucursalesHasProveedores.equals(other.idSucursalesHasProveedores))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.SucursalesHasProveedores[ idSucursalesHasProveedores=" + idSucursalesHasProveedores + " ]";
    }
    
}

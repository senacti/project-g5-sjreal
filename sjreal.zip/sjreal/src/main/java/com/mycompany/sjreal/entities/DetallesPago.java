/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "detalles_pago")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DetallesPago.findAll", query = "SELECT d FROM DetallesPago d"),
    @NamedQuery(name = "DetallesPago.findByIdDetallePago", query = "SELECT d FROM DetallesPago d WHERE d.idDetallePago = :idDetallePago"),
    @NamedQuery(name = "DetallesPago.findByPrecioPorItem", query = "SELECT d FROM DetallesPago d WHERE d.precioPorItem = :precioPorItem"),
    @NamedQuery(name = "DetallesPago.findByCantidadItem", query = "SELECT d FROM DetallesPago d WHERE d.cantidadItem = :cantidadItem"),
    @NamedQuery(name = "DetallesPago.findByDetallePagoPrecioTotal", query = "SELECT d FROM DetallesPago d WHERE d.detallePagoPrecioTotal = :detallePagoPrecioTotal")})
public class DetallesPago implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_Detalle_Pago")
    private Integer idDetallePago;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio_por_item")
    private long precioPorItem;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidad_item")
    private int cantidadItem;
    @Basic(optional = false)
    @NotNull
    @Column(name = "detalle_pago_precio_total")
    private long detallePagoPrecioTotal;
    @JoinColumn(name = "detalle_pago_id_pago", referencedColumnName = "id_pago")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Pagos detallePagoIdPago;
    @JoinColumn(name = "detalle_pago_id_producto", referencedColumnName = "id_producto")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Productos detallePagoIdProducto;

    public DetallesPago() {
    }

    public DetallesPago(Integer idDetallePago) {
        this.idDetallePago = idDetallePago;
    }

    public DetallesPago(Integer idDetallePago, long precioPorItem, int cantidadItem, long detallePagoPrecioTotal) {
        this.idDetallePago = idDetallePago;
        this.precioPorItem = precioPorItem;
        this.cantidadItem = cantidadItem;
        this.detallePagoPrecioTotal = detallePagoPrecioTotal;
    }

    public Integer getIdDetallePago() {
        return idDetallePago;
    }

    public void setIdDetallePago(Integer idDetallePago) {
        this.idDetallePago = idDetallePago;
    }

    public long getPrecioPorItem() {
        return precioPorItem;
    }

    public void setPrecioPorItem(long precioPorItem) {
        this.precioPorItem = precioPorItem;
    }

    public int getCantidadItem() {
        return cantidadItem;
    }

    public void setCantidadItem(int cantidadItem) {
        this.cantidadItem = cantidadItem;
    }

    public long getDetallePagoPrecioTotal() {
        return detallePagoPrecioTotal;
    }

    public void setDetallePagoPrecioTotal(long detallePagoPrecioTotal) {
        this.detallePagoPrecioTotal = detallePagoPrecioTotal;
    }

    public Pagos getDetallePagoIdPago() {
        return detallePagoIdPago;
    }

    public void setDetallePagoIdPago(Pagos detallePagoIdPago) {
        this.detallePagoIdPago = detallePagoIdPago;
    }

    public Productos getDetallePagoIdProducto() {
        return detallePagoIdProducto;
    }

    public void setDetallePagoIdProducto(Productos detallePagoIdProducto) {
        this.detallePagoIdProducto = detallePagoIdProducto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDetallePago != null ? idDetallePago.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DetallesPago)) {
            return false;
        }
        DetallesPago other = (DetallesPago) object;
        if ((this.idDetallePago == null && other.idDetallePago != null) || (this.idDetallePago != null && !this.idDetallePago.equals(other.idDetallePago))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.DetallesPago[ idDetallePago=" + idDetallePago + " ]";
    }
    
}

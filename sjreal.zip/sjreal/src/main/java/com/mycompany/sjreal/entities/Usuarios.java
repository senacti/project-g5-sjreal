/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "usuarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuarios.findAll", query = "SELECT u FROM Usuarios u"),
    @NamedQuery(name = "Usuarios.findByPersonasIdPersona", query = "SELECT u FROM Usuarios u WHERE u.personasIdPersona = :personasIdPersona"),
    @NamedQuery(name = "Usuarios.findByContrasenaUsuario", query = "SELECT u FROM Usuarios u WHERE u.contrasenaUsuario = :contrasenaUsuario"),
    @NamedQuery(name = "Usuarios.findByNombreUsuario", query = "SELECT u FROM Usuarios u WHERE u.nombreUsuario = :nombreUsuario")})
public class Usuarios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "personas_id_persona")
    private Integer personasIdPersona;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "contrasena_usuario")
    private String contrasenaUsuario;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "nombre_usuario")
    private String nombreUsuario;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pedidoIdUsuario", fetch = FetchType.LAZY)
    private List<Pedidos> pedidosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pagoIdPersona", fetch = FetchType.LAZY)
    private List<Pagos> pagosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "usuarioIdPersona", fetch = FetchType.LAZY)
    private List<Personas> personasList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vehiculoIdUsuario", fetch = FetchType.LAZY)
    private List<Vehiculos> vehiculosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "usuariosPersonasIdPersona", fetch = FetchType.LAZY)
    private List<Hospedajes> hospedajesList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "usuarioIdSucursal", fetch = FetchType.LAZY)
    private List<Sucursales> sucursalesList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "usuariosPersonasIdPersona", fetch = FetchType.LAZY)
    private List<RolesHasUsuarios> rolesHasUsuariosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pqrsIdUsuario", fetch = FetchType.LAZY)
    private List<Pqrs> pqrsList;

    public Usuarios() {
    }

    public Usuarios(Integer personasIdPersona) {
        this.personasIdPersona = personasIdPersona;
    }

    public Usuarios(Integer personasIdPersona, String contrasenaUsuario, String nombreUsuario) {
        this.personasIdPersona = personasIdPersona;
        this.contrasenaUsuario = contrasenaUsuario;
        this.nombreUsuario = nombreUsuario;
    }

    public Integer getPersonasIdPersona() {
        return personasIdPersona;
    }

    public void setPersonasIdPersona(Integer personasIdPersona) {
        this.personasIdPersona = personasIdPersona;
    }

    public String getContrasenaUsuario() {
        return contrasenaUsuario;
    }

    public void setContrasenaUsuario(String contrasenaUsuario) {
        this.contrasenaUsuario = contrasenaUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    @XmlTransient
    public List<Pedidos> getPedidosList() {
        return pedidosList;
    }

    public void setPedidosList(List<Pedidos> pedidosList) {
        this.pedidosList = pedidosList;
    }

    @XmlTransient
    public List<Pagos> getPagosList() {
        return pagosList;
    }

    public void setPagosList(List<Pagos> pagosList) {
        this.pagosList = pagosList;
    }

    @XmlTransient
    public List<Personas> getPersonasList() {
        return personasList;
    }

    public void setPersonasList(List<Personas> personasList) {
        this.personasList = personasList;
    }

    @XmlTransient
    public List<Vehiculos> getVehiculosList() {
        return vehiculosList;
    }

    public void setVehiculosList(List<Vehiculos> vehiculosList) {
        this.vehiculosList = vehiculosList;
    }

    @XmlTransient
    public List<Hospedajes> getHospedajesList() {
        return hospedajesList;
    }

    public void setHospedajesList(List<Hospedajes> hospedajesList) {
        this.hospedajesList = hospedajesList;
    }

    @XmlTransient
    public List<Sucursales> getSucursalesList() {
        return sucursalesList;
    }

    public void setSucursalesList(List<Sucursales> sucursalesList) {
        this.sucursalesList = sucursalesList;
    }

    @XmlTransient
    public List<RolesHasUsuarios> getRolesHasUsuariosList() {
        return rolesHasUsuariosList;
    }

    public void setRolesHasUsuariosList(List<RolesHasUsuarios> rolesHasUsuariosList) {
        this.rolesHasUsuariosList = rolesHasUsuariosList;
    }

    @XmlTransient
    public List<Pqrs> getPqrsList() {
        return pqrsList;
    }

    public void setPqrsList(List<Pqrs> pqrsList) {
        this.pqrsList = pqrsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (personasIdPersona != null ? personasIdPersona.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuarios)) {
            return false;
        }
        Usuarios other = (Usuarios) object;
        if ((this.personasIdPersona == null && other.personasIdPersona != null) || (this.personasIdPersona != null && !this.personasIdPersona.equals(other.personasIdPersona))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Usuarios[ personasIdPersona=" + personasIdPersona + " ]";
    }
    
}

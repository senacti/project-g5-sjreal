/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "hospedajes")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hospedajes.findAll", query = "SELECT h FROM Hospedajes h"),
    @NamedQuery(name = "Hospedajes.findByIdHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.idHospedaje = :idHospedaje"),
    @NamedQuery(name = "Hospedajes.findByCheckInHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.checkInHospedaje = :checkInHospedaje"),
    @NamedQuery(name = "Hospedajes.findByCheckOutHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.checkOutHospedaje = :checkOutHospedaje"),
    @NamedQuery(name = "Hospedajes.findByCantidadHabitacionesHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.cantidadHabitacionesHospedaje = :cantidadHabitacionesHospedaje"),
    @NamedQuery(name = "Hospedajes.findByCantidadPersonasHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.cantidadPersonasHospedaje = :cantidadPersonasHospedaje"),
    @NamedQuery(name = "Hospedajes.findByDiasHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.diasHospedaje = :diasHospedaje"),
    @NamedQuery(name = "Hospedajes.findByEstadoHospedaje", query = "SELECT h FROM Hospedajes h WHERE h.estadoHospedaje = :estadoHospedaje")})
public class Hospedajes implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_hospedaje")
    private Integer idHospedaje;
    @Basic(optional = false)
    @NotNull
    @Column(name = "check_in_hospedaje")
    @Temporal(TemporalType.TIMESTAMP)
    private Date checkInHospedaje;
    @Basic(optional = false)
    @NotNull
    @Column(name = "check_out_hospedaje")
    @Temporal(TemporalType.TIMESTAMP)
    private Date checkOutHospedaje;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidad_habitaciones_hospedaje")
    private int cantidadHabitacionesHospedaje;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidad_personas_hospedaje")
    private int cantidadPersonasHospedaje;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dias_hospedaje")
    private int diasHospedaje;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 9)
    @Column(name = "estado_hospedaje")
    private String estadoHospedaje;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hospedajeIdHospedaje", fetch = FetchType.LAZY)
    private List<Parqueadero> parqueaderoList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pagoIdHospedaje", fetch = FetchType.LAZY)
    private List<Pagos> pagosList;
    @JoinColumn(name = "habitacion_i_habitacion", referencedColumnName = "id_habitacion")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Habitaciones habitacionIHabitacion;
    @JoinColumn(name = "usuarios_personas_id_persona", referencedColumnName = "personas_id_persona")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Usuarios usuariosPersonasIdPersona;

    public Hospedajes() {
    }

    public Hospedajes(Integer idHospedaje) {
        this.idHospedaje = idHospedaje;
    }

    public Hospedajes(Integer idHospedaje, Date checkInHospedaje, Date checkOutHospedaje, int cantidadHabitacionesHospedaje, int cantidadPersonasHospedaje, int diasHospedaje, String estadoHospedaje) {
        this.idHospedaje = idHospedaje;
        this.checkInHospedaje = checkInHospedaje;
        this.checkOutHospedaje = checkOutHospedaje;
        this.cantidadHabitacionesHospedaje = cantidadHabitacionesHospedaje;
        this.cantidadPersonasHospedaje = cantidadPersonasHospedaje;
        this.diasHospedaje = diasHospedaje;
        this.estadoHospedaje = estadoHospedaje;
    }

    public Integer getIdHospedaje() {
        return idHospedaje;
    }

    public void setIdHospedaje(Integer idHospedaje) {
        this.idHospedaje = idHospedaje;
    }

    public Date getCheckInHospedaje() {
        return checkInHospedaje;
    }

    public void setCheckInHospedaje(Date checkInHospedaje) {
        this.checkInHospedaje = checkInHospedaje;
    }

    public Date getCheckOutHospedaje() {
        return checkOutHospedaje;
    }

    public void setCheckOutHospedaje(Date checkOutHospedaje) {
        this.checkOutHospedaje = checkOutHospedaje;
    }

    public int getCantidadHabitacionesHospedaje() {
        return cantidadHabitacionesHospedaje;
    }

    public void setCantidadHabitacionesHospedaje(int cantidadHabitacionesHospedaje) {
        this.cantidadHabitacionesHospedaje = cantidadHabitacionesHospedaje;
    }

    public int getCantidadPersonasHospedaje() {
        return cantidadPersonasHospedaje;
    }

    public void setCantidadPersonasHospedaje(int cantidadPersonasHospedaje) {
        this.cantidadPersonasHospedaje = cantidadPersonasHospedaje;
    }

    public int getDiasHospedaje() {
        return diasHospedaje;
    }

    public void setDiasHospedaje(int diasHospedaje) {
        this.diasHospedaje = diasHospedaje;
    }

    public String getEstadoHospedaje() {
        return estadoHospedaje;
    }

    public void setEstadoHospedaje(String estadoHospedaje) {
        this.estadoHospedaje = estadoHospedaje;
    }

    @XmlTransient
    public List<Parqueadero> getParqueaderoList() {
        return parqueaderoList;
    }

    public void setParqueaderoList(List<Parqueadero> parqueaderoList) {
        this.parqueaderoList = parqueaderoList;
    }

    @XmlTransient
    public List<Pagos> getPagosList() {
        return pagosList;
    }

    public void setPagosList(List<Pagos> pagosList) {
        this.pagosList = pagosList;
    }

    public Habitaciones getHabitacionIHabitacion() {
        return habitacionIHabitacion;
    }

    public void setHabitacionIHabitacion(Habitaciones habitacionIHabitacion) {
        this.habitacionIHabitacion = habitacionIHabitacion;
    }

    public Usuarios getUsuariosPersonasIdPersona() {
        return usuariosPersonasIdPersona;
    }

    public void setUsuariosPersonasIdPersona(Usuarios usuariosPersonasIdPersona) {
        this.usuariosPersonasIdPersona = usuariosPersonasIdPersona;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHospedaje != null ? idHospedaje.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hospedajes)) {
            return false;
        }
        Hospedajes other = (Hospedajes) object;
        if ((this.idHospedaje == null && other.idHospedaje != null) || (this.idHospedaje != null && !this.idHospedaje.equals(other.idHospedaje))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Hospedajes[ idHospedaje=" + idHospedaje + " ]";
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "productos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Productos.findAll", query = "SELECT p FROM Productos p"),
    @NamedQuery(name = "Productos.findByIdProducto", query = "SELECT p FROM Productos p WHERE p.idProducto = :idProducto"),
    @NamedQuery(name = "Productos.findByPrecioProducto", query = "SELECT p FROM Productos p WHERE p.precioProducto = :precioProducto"),
    @NamedQuery(name = "Productos.findByDescripcionProducto", query = "SELECT p FROM Productos p WHERE p.descripcionProducto = :descripcionProducto"),
    @NamedQuery(name = "Productos.findByNombreProducto", query = "SELECT p FROM Productos p WHERE p.nombreProducto = :nombreProducto"),
    @NamedQuery(name = "Productos.findByEstadoProducto", query = "SELECT p FROM Productos p WHERE p.estadoProducto = :estadoProducto"),
    @NamedQuery(name = "Productos.findByExistenciasProducto", query = "SELECT p FROM Productos p WHERE p.existenciasProducto = :existenciasProducto"),
    @NamedQuery(name = "Productos.findByMaximoProducto", query = "SELECT p FROM Productos p WHERE p.maximoProducto = :maximoProducto"),
    @NamedQuery(name = "Productos.findByMinimoProducto", query = "SELECT p FROM Productos p WHERE p.minimoProducto = :minimoProducto"),
    @NamedQuery(name = "Productos.findByTipoProducto", query = "SELECT p FROM Productos p WHERE p.tipoProducto = :tipoProducto")})
public class Productos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_producto")
    private Integer idProducto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio_producto")
    private long precioProducto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "descripcion_producto")
    private String descripcionProducto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nombre_producto")
    private String nombreProducto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "estado_producto")
    private String estadoProducto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "existencias_producto")
    private int existenciasProducto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "maximo_producto")
    private int maximoProducto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "minimo_producto")
    private int minimoProducto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "tipo_producto")
    private String tipoProducto;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "detallePagoIdProducto", fetch = FetchType.LAZY)
    private List<DetallesPago> detallesPagoList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "controlInventarioIdProducto", fetch = FetchType.LAZY)
    private List<ControlInventarios> controlInventariosList;

    public Productos() {
    }

    public Productos(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public Productos(Integer idProducto, long precioProducto, String descripcionProducto, String nombreProducto, String estadoProducto, int existenciasProducto, int maximoProducto, int minimoProducto, String tipoProducto) {
        this.idProducto = idProducto;
        this.precioProducto = precioProducto;
        this.descripcionProducto = descripcionProducto;
        this.nombreProducto = nombreProducto;
        this.estadoProducto = estadoProducto;
        this.existenciasProducto = existenciasProducto;
        this.maximoProducto = maximoProducto;
        this.minimoProducto = minimoProducto;
        this.tipoProducto = tipoProducto;
    }

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public long getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(long precioProducto) {
        this.precioProducto = precioProducto;
    }

    public String getDescripcionProducto() {
        return descripcionProducto;
    }

    public void setDescripcionProducto(String descripcionProducto) {
        this.descripcionProducto = descripcionProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getEstadoProducto() {
        return estadoProducto;
    }

    public void setEstadoProducto(String estadoProducto) {
        this.estadoProducto = estadoProducto;
    }

    public int getExistenciasProducto() {
        return existenciasProducto;
    }

    public void setExistenciasProducto(int existenciasProducto) {
        this.existenciasProducto = existenciasProducto;
    }

    public int getMaximoProducto() {
        return maximoProducto;
    }

    public void setMaximoProducto(int maximoProducto) {
        this.maximoProducto = maximoProducto;
    }

    public int getMinimoProducto() {
        return minimoProducto;
    }

    public void setMinimoProducto(int minimoProducto) {
        this.minimoProducto = minimoProducto;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    @XmlTransient
    public List<DetallesPago> getDetallesPagoList() {
        return detallesPagoList;
    }

    public void setDetallesPagoList(List<DetallesPago> detallesPagoList) {
        this.detallesPagoList = detallesPagoList;
    }

    @XmlTransient
    public List<ControlInventarios> getControlInventariosList() {
        return controlInventariosList;
    }

    public void setControlInventariosList(List<ControlInventarios> controlInventariosList) {
        this.controlInventariosList = controlInventariosList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idProducto != null ? idProducto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Productos)) {
            return false;
        }
        Productos other = (Productos) object;
        if ((this.idProducto == null && other.idProducto != null) || (this.idProducto != null && !this.idProducto.equals(other.idProducto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Productos[ idProducto=" + idProducto + " ]";
    }
    
}

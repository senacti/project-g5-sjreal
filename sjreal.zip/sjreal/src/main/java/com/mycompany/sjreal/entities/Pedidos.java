/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "pedidos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pedidos.findAll", query = "SELECT p FROM Pedidos p"),
    @NamedQuery(name = "Pedidos.findByIdPedido", query = "SELECT p FROM Pedidos p WHERE p.idPedido = :idPedido"),
    @NamedQuery(name = "Pedidos.findByCantidadProducto", query = "SELECT p FROM Pedidos p WHERE p.cantidadProducto = :cantidadProducto"),
    @NamedQuery(name = "Pedidos.findByFechaEntrega", query = "SELECT p FROM Pedidos p WHERE p.fechaEntrega = :fechaEntrega"),
    @NamedQuery(name = "Pedidos.findByPrecioTotalPedido", query = "SELECT p FROM Pedidos p WHERE p.precioTotalPedido = :precioTotalPedido"),
    @NamedQuery(name = "Pedidos.findByPrecioUnitarioProducto", query = "SELECT p FROM Pedidos p WHERE p.precioUnitarioProducto = :precioUnitarioProducto")})
public class Pedidos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IdPedido")
    private Integer idPedido;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidad_producto")
    private int cantidadProducto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_entrega")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaEntrega;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio_total_pedido")
    private long precioTotalPedido;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio_unitario_producto")
    private long precioUnitarioProducto;
    @JoinColumn(name = "pedido_id_usuario", referencedColumnName = "personas_id_persona")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Usuarios pedidoIdUsuario;
    @JoinColumn(name = "pedido_id_proveedor", referencedColumnName = "id_proveedor")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Proveedores pedidoIdProveedor;
    @JoinColumn(name = "pedido_id_control_inventario", referencedColumnName = "id_control_inventario")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private ControlInventarios pedidoIdControlInventario;

    public Pedidos() {
    }

    public Pedidos(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public Pedidos(Integer idPedido, int cantidadProducto, Date fechaEntrega, long precioTotalPedido, long precioUnitarioProducto) {
        this.idPedido = idPedido;
        this.cantidadProducto = cantidadProducto;
        this.fechaEntrega = fechaEntrega;
        this.precioTotalPedido = precioTotalPedido;
        this.precioUnitarioProducto = precioUnitarioProducto;
    }

    public Integer getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public int getCantidadProducto() {
        return cantidadProducto;
    }

    public void setCantidadProducto(int cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public long getPrecioTotalPedido() {
        return precioTotalPedido;
    }

    public void setPrecioTotalPedido(long precioTotalPedido) {
        this.precioTotalPedido = precioTotalPedido;
    }

    public long getPrecioUnitarioProducto() {
        return precioUnitarioProducto;
    }

    public void setPrecioUnitarioProducto(long precioUnitarioProducto) {
        this.precioUnitarioProducto = precioUnitarioProducto;
    }

    public Usuarios getPedidoIdUsuario() {
        return pedidoIdUsuario;
    }

    public void setPedidoIdUsuario(Usuarios pedidoIdUsuario) {
        this.pedidoIdUsuario = pedidoIdUsuario;
    }

    public Proveedores getPedidoIdProveedor() {
        return pedidoIdProveedor;
    }

    public void setPedidoIdProveedor(Proveedores pedidoIdProveedor) {
        this.pedidoIdProveedor = pedidoIdProveedor;
    }

    public ControlInventarios getPedidoIdControlInventario() {
        return pedidoIdControlInventario;
    }

    public void setPedidoIdControlInventario(ControlInventarios pedidoIdControlInventario) {
        this.pedidoIdControlInventario = pedidoIdControlInventario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPedido != null ? idPedido.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pedidos)) {
            return false;
        }
        Pedidos other = (Pedidos) object;
        if ((this.idPedido == null && other.idPedido != null) || (this.idPedido != null && !this.idPedido.equals(other.idPedido))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Pedidos[ idPedido=" + idPedido + " ]";
    }
    
}

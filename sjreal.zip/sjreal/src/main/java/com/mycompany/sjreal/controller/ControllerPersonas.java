/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.sjreal.controller;

import com.mycompany.sjreal.entities.Personas;
import com.mycompany.sjreal.model.PersonasFacadeLocal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author usuario
 */
@Named(value = "controllerPersonas")
@SessionScoped
public class ControllerPersonas implements Serializable {

    /**
     * Creates a new instance of ControllerPersonas
     */
    private Personas persona = new Personas();
    @EJB
    private PersonasFacadeLocal pf1;
    private FacesContext contexto;
    private FacesMessage fm;
    
    public ControllerPersonas() {
    }

    public Personas getPersona() {
        return persona;
    }

    public void setPersona(Personas persona) {
        this.persona = persona;
    }
    
    public void crearPersona() {
        contexto = FacesContext.getCurrentInstance();
        try {
            this.pf1.create(persona);
            fm = new FacesMessage(FacesMessage.SEVERITY_INFO, "Se creo la persona", "MSG_INFO");
        } catch(Exception e) {
            fm = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "MSG_ERROR");
        }
        contexto.addMessage(null, fm);
    }
    
    public List<Personas> listaPersonas() {
        try {
            return this.pf1.findAll();
        } catch (Exception e) {           
        }
        return null;
    }
}

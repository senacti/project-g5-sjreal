/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "habitaciones")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Habitaciones.findAll", query = "SELECT h FROM Habitaciones h"),
    @NamedQuery(name = "Habitaciones.findByIdHabitacion", query = "SELECT h FROM Habitaciones h WHERE h.idHabitacion = :idHabitacion"),
    @NamedQuery(name = "Habitaciones.findByNumeroHabitacion", query = "SELECT h FROM Habitaciones h WHERE h.numeroHabitacion = :numeroHabitacion"),
    @NamedQuery(name = "Habitaciones.findByDescripcionHabitacion", query = "SELECT h FROM Habitaciones h WHERE h.descripcionHabitacion = :descripcionHabitacion"),
    @NamedQuery(name = "Habitaciones.findByTipoHabitacion", query = "SELECT h FROM Habitaciones h WHERE h.tipoHabitacion = :tipoHabitacion"),
    @NamedQuery(name = "Habitaciones.findByCapacidadHabitacion", query = "SELECT h FROM Habitaciones h WHERE h.capacidadHabitacion = :capacidadHabitacion"),
    @NamedQuery(name = "Habitaciones.findByPrecioHabitacion", query = "SELECT h FROM Habitaciones h WHERE h.precioHabitacion = :precioHabitacion")})
public class Habitaciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_habitacion")
    private Integer idHabitacion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "numero_habitacion")
    private String numeroHabitacion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 500)
    @Column(name = "descripcion_habitacion")
    private String descripcionHabitacion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 11)
    @Column(name = "tipo_habitacion")
    private String tipoHabitacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "capacidad_habitacion")
    private int capacidadHabitacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio_habitacion")
    private long precioHabitacion;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "habitacionIHabitacion", fetch = FetchType.LAZY)
    private List<Hospedajes> hospedajesList;
    @JoinColumn(name = "habitacion_id_sucursal", referencedColumnName = "id_sucursal")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Sucursales habitacionIdSucursal;

    public Habitaciones() {
    }

    public Habitaciones(Integer idHabitacion) {
        this.idHabitacion = idHabitacion;
    }

    public Habitaciones(Integer idHabitacion, String numeroHabitacion, String descripcionHabitacion, String tipoHabitacion, int capacidadHabitacion, long precioHabitacion) {
        this.idHabitacion = idHabitacion;
        this.numeroHabitacion = numeroHabitacion;
        this.descripcionHabitacion = descripcionHabitacion;
        this.tipoHabitacion = tipoHabitacion;
        this.capacidadHabitacion = capacidadHabitacion;
        this.precioHabitacion = precioHabitacion;
    }

    public Integer getIdHabitacion() {
        return idHabitacion;
    }

    public void setIdHabitacion(Integer idHabitacion) {
        this.idHabitacion = idHabitacion;
    }

    public String getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public void setNumeroHabitacion(String numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public String getDescripcionHabitacion() {
        return descripcionHabitacion;
    }

    public void setDescripcionHabitacion(String descripcionHabitacion) {
        this.descripcionHabitacion = descripcionHabitacion;
    }

    public String getTipoHabitacion() {
        return tipoHabitacion;
    }

    public void setTipoHabitacion(String tipoHabitacion) {
        this.tipoHabitacion = tipoHabitacion;
    }

    public int getCapacidadHabitacion() {
        return capacidadHabitacion;
    }

    public void setCapacidadHabitacion(int capacidadHabitacion) {
        this.capacidadHabitacion = capacidadHabitacion;
    }

    public long getPrecioHabitacion() {
        return precioHabitacion;
    }

    public void setPrecioHabitacion(long precioHabitacion) {
        this.precioHabitacion = precioHabitacion;
    }

    @XmlTransient
    public List<Hospedajes> getHospedajesList() {
        return hospedajesList;
    }

    public void setHospedajesList(List<Hospedajes> hospedajesList) {
        this.hospedajesList = hospedajesList;
    }

    public Sucursales getHabitacionIdSucursal() {
        return habitacionIdSucursal;
    }

    public void setHabitacionIdSucursal(Sucursales habitacionIdSucursal) {
        this.habitacionIdSucursal = habitacionIdSucursal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHabitacion != null ? idHabitacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Habitaciones)) {
            return false;
        }
        Habitaciones other = (Habitaciones) object;
        if ((this.idHabitacion == null && other.idHabitacion != null) || (this.idHabitacion != null && !this.idHabitacion.equals(other.idHabitacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Habitaciones[ idHabitacion=" + idHabitacion + " ]";
    }
    
}

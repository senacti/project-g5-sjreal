/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sjreal.model;

import com.mycompany.sjreal.entities.Parqueadero;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author usuario
 */
@Local
public interface ParqueaderoFacadeLocal {

    void create(Parqueadero parqueadero);

    void edit(Parqueadero parqueadero);

    void remove(Parqueadero parqueadero);

    Parqueadero find(Object id);

    List<Parqueadero> findAll();

    List<Parqueadero> findRange(int[] range);

    int count();
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "pagos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pagos.findAll", query = "SELECT p FROM Pagos p"),
    @NamedQuery(name = "Pagos.findByIdPago", query = "SELECT p FROM Pagos p WHERE p.idPago = :idPago"),
    @NamedQuery(name = "Pagos.findByTitularPago", query = "SELECT p FROM Pagos p WHERE p.titularPago = :titularPago"),
    @NamedQuery(name = "Pagos.findByMedioPago", query = "SELECT p FROM Pagos p WHERE p.medioPago = :medioPago"),
    @NamedQuery(name = "Pagos.findByConceptoPago", query = "SELECT p FROM Pagos p WHERE p.conceptoPago = :conceptoPago"),
    @NamedQuery(name = "Pagos.findByTotalPago", query = "SELECT p FROM Pagos p WHERE p.totalPago = :totalPago"),
    @NamedQuery(name = "Pagos.findByTipoCliente", query = "SELECT p FROM Pagos p WHERE p.tipoCliente = :tipoCliente")})
public class Pagos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_pago")
    private Integer idPago;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 80)
    @Column(name = "titular_pago")
    private String titularPago;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 18)
    @Column(name = "medio_pago")
    private String medioPago;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 500)
    @Column(name = "concepto_pago")
    private String conceptoPago;
    @Basic(optional = false)
    @NotNull
    @Column(name = "total_pago")
    private long totalPago;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 16)
    @Column(name = "tipo_cliente")
    private String tipoCliente;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "detallePagoIdPago", fetch = FetchType.LAZY)
    private List<DetallesPago> detallesPagoList;
    @JoinColumn(name = "pago_id_persona", referencedColumnName = "personas_id_persona")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Usuarios pagoIdPersona;
    @JoinColumn(name = "pago_id_hospedaje", referencedColumnName = "id_hospedaje")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Hospedajes pagoIdHospedaje;

    public Pagos() {
    }

    public Pagos(Integer idPago) {
        this.idPago = idPago;
    }

    public Pagos(Integer idPago, String titularPago, String medioPago, String conceptoPago, long totalPago, String tipoCliente) {
        this.idPago = idPago;
        this.titularPago = titularPago;
        this.medioPago = medioPago;
        this.conceptoPago = conceptoPago;
        this.totalPago = totalPago;
        this.tipoCliente = tipoCliente;
    }

    public Integer getIdPago() {
        return idPago;
    }

    public void setIdPago(Integer idPago) {
        this.idPago = idPago;
    }

    public String getTitularPago() {
        return titularPago;
    }

    public void setTitularPago(String titularPago) {
        this.titularPago = titularPago;
    }

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }

    public String getConceptoPago() {
        return conceptoPago;
    }

    public void setConceptoPago(String conceptoPago) {
        this.conceptoPago = conceptoPago;
    }

    public long getTotalPago() {
        return totalPago;
    }

    public void setTotalPago(long totalPago) {
        this.totalPago = totalPago;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(String tipoCliente) {
        this.tipoCliente = tipoCliente;
    }

    @XmlTransient
    public List<DetallesPago> getDetallesPagoList() {
        return detallesPagoList;
    }

    public void setDetallesPagoList(List<DetallesPago> detallesPagoList) {
        this.detallesPagoList = detallesPagoList;
    }

    public Usuarios getPagoIdPersona() {
        return pagoIdPersona;
    }

    public void setPagoIdPersona(Usuarios pagoIdPersona) {
        this.pagoIdPersona = pagoIdPersona;
    }

    public Hospedajes getPagoIdHospedaje() {
        return pagoIdHospedaje;
    }

    public void setPagoIdHospedaje(Hospedajes pagoIdHospedaje) {
        this.pagoIdHospedaje = pagoIdHospedaje;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPago != null ? idPago.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pagos)) {
            return false;
        }
        Pagos other = (Pagos) object;
        if ((this.idPago == null && other.idPago != null) || (this.idPago != null && !this.idPago.equals(other.idPago))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Pagos[ idPago=" + idPago + " ]";
    }
    
}

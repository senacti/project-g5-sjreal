/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "control_inventarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ControlInventarios.findAll", query = "SELECT c FROM ControlInventarios c"),
    @NamedQuery(name = "ControlInventarios.findByIdControlInventario", query = "SELECT c FROM ControlInventarios c WHERE c.idControlInventario = :idControlInventario"),
    @NamedQuery(name = "ControlInventarios.findByFechaActualizacion", query = "SELECT c FROM ControlInventarios c WHERE c.fechaActualizacion = :fechaActualizacion"),
    @NamedQuery(name = "ControlInventarios.findByTipopActualizacion", query = "SELECT c FROM ControlInventarios c WHERE c.tipopActualizacion = :tipopActualizacion"),
    @NamedQuery(name = "ControlInventarios.findByCantidadA\u00f1adida", query = "SELECT c FROM ControlInventarios c WHERE c.cantidadA\u00f1adida = :cantidadA\u00f1adida"),
    @NamedQuery(name = "ControlInventarios.findByCantidadRestada", query = "SELECT c FROM ControlInventarios c WHERE c.cantidadRestada = :cantidadRestada")})
public class ControlInventarios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_control_inventario")
    private Integer idControlInventario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_actualizacion")
    @Temporal(TemporalType.DATE)
    private Date fechaActualizacion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 27)
    @Column(name = "tipop_actualizacion")
    private String tipopActualizacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidad_a\u00f1adida")
    private int cantidadAñadida;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidad_restada")
    private int cantidadRestada;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pedidoIdControlInventario", fetch = FetchType.LAZY)
    private List<Pedidos> pedidosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "controlrioidControlInventario", fetch = FetchType.LAZY)
    private List<Iventarios> iventariosList;
    @JoinColumn(name = "control_inventario_id_producto", referencedColumnName = "id_producto")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Productos controlInventarioIdProducto;

    public ControlInventarios() {
    }

    public ControlInventarios(Integer idControlInventario) {
        this.idControlInventario = idControlInventario;
    }

    public ControlInventarios(Integer idControlInventario, Date fechaActualizacion, String tipopActualizacion, int cantidadAñadida, int cantidadRestada) {
        this.idControlInventario = idControlInventario;
        this.fechaActualizacion = fechaActualizacion;
        this.tipopActualizacion = tipopActualizacion;
        this.cantidadAñadida = cantidadAñadida;
        this.cantidadRestada = cantidadRestada;
    }

    public Integer getIdControlInventario() {
        return idControlInventario;
    }

    public void setIdControlInventario(Integer idControlInventario) {
        this.idControlInventario = idControlInventario;
    }

    public Date getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(Date fechaActualizacion) {
        this.fechaActualizacion = fechaActualizacion;
    }

    public String getTipopActualizacion() {
        return tipopActualizacion;
    }

    public void setTipopActualizacion(String tipopActualizacion) {
        this.tipopActualizacion = tipopActualizacion;
    }

    public int getCantidadAñadida() {
        return cantidadAñadida;
    }

    public void setCantidadAñadida(int cantidadAñadida) {
        this.cantidadAñadida = cantidadAñadida;
    }

    public int getCantidadRestada() {
        return cantidadRestada;
    }

    public void setCantidadRestada(int cantidadRestada) {
        this.cantidadRestada = cantidadRestada;
    }

    @XmlTransient
    public List<Pedidos> getPedidosList() {
        return pedidosList;
    }

    public void setPedidosList(List<Pedidos> pedidosList) {
        this.pedidosList = pedidosList;
    }

    @XmlTransient
    public List<Iventarios> getIventariosList() {
        return iventariosList;
    }

    public void setIventariosList(List<Iventarios> iventariosList) {
        this.iventariosList = iventariosList;
    }

    public Productos getControlInventarioIdProducto() {
        return controlInventarioIdProducto;
    }

    public void setControlInventarioIdProducto(Productos controlInventarioIdProducto) {
        this.controlInventarioIdProducto = controlInventarioIdProducto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idControlInventario != null ? idControlInventario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ControlInventarios)) {
            return false;
        }
        ControlInventarios other = (ControlInventarios) object;
        if ((this.idControlInventario == null && other.idControlInventario != null) || (this.idControlInventario != null && !this.idControlInventario.equals(other.idControlInventario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.ControlInventarios[ idControlInventario=" + idControlInventario + " ]";
    }
    
}

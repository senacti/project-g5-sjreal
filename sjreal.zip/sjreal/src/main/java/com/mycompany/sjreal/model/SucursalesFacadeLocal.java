/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sjreal.model;

import com.mycompany.sjreal.entities.Sucursales;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author usuario
 */
@Local
public interface SucursalesFacadeLocal {

    void create(Sucursales sucursales);

    void edit(Sucursales sucursales);

    void remove(Sucursales sucursales);

    Sucursales find(Object id);

    List<Sucursales> findAll();

    List<Sucursales> findRange(int[] range);

    int count();
    
}

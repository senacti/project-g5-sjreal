/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sjreal.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "huesped")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Huesped.findAll", query = "SELECT h FROM Huesped h"),
    @NamedQuery(name = "Huesped.findByIdHuesped", query = "SELECT h FROM Huesped h WHERE h.idHuesped = :idHuesped"),
    @NamedQuery(name = "Huesped.findByCedulaHuesped", query = "SELECT h FROM Huesped h WHERE h.cedulaHuesped = :cedulaHuesped"),
    @NamedQuery(name = "Huesped.findByPrimerNombreHuesped", query = "SELECT h FROM Huesped h WHERE h.primerNombreHuesped = :primerNombreHuesped"),
    @NamedQuery(name = "Huesped.findBySegundoNombreHuesped", query = "SELECT h FROM Huesped h WHERE h.segundoNombreHuesped = :segundoNombreHuesped"),
    @NamedQuery(name = "Huesped.findByPrimerApellidoHuesped", query = "SELECT h FROM Huesped h WHERE h.primerApellidoHuesped = :primerApellidoHuesped"),
    @NamedQuery(name = "Huesped.findBySegundoApellidoHuesped", query = "SELECT h FROM Huesped h WHERE h.segundoApellidoHuesped = :segundoApellidoHuesped"),
    @NamedQuery(name = "Huesped.findByTipoDocumentoHuesped", query = "SELECT h FROM Huesped h WHERE h.tipoDocumentoHuesped = :tipoDocumentoHuesped"),
    @NamedQuery(name = "Huesped.findByFechaNacimientoHuesped", query = "SELECT h FROM Huesped h WHERE h.fechaNacimientoHuesped = :fechaNacimientoHuesped"),
    @NamedQuery(name = "Huesped.findByEdadHuesped", query = "SELECT h FROM Huesped h WHERE h.edadHuesped = :edadHuesped"),
    @NamedQuery(name = "Huesped.findByTelefonoHuesped", query = "SELECT h FROM Huesped h WHERE h.telefonoHuesped = :telefonoHuesped"),
    @NamedQuery(name = "Huesped.findByCorreoHuesped", query = "SELECT h FROM Huesped h WHERE h.correoHuesped = :correoHuesped")})
public class Huesped implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idHuesped")
    private Integer idHuesped;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "cedula _Huesped")
    private String cedulaHuesped;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "primer_Nombre_Huesped")
    private String primerNombreHuesped;
    @Size(max = 40)
    @Column(name = "segundo_Nombre_Huesped")
    private String segundoNombreHuesped;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "primer_Apellido_Huesped")
    private String primerApellidoHuesped;
    @Size(max = 45)
    @Column(name = "segundo_Apellido_Huesped")
    private String segundoApellidoHuesped;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 9)
    @Column(name = "tipo_Documento_Huesped")
    private String tipoDocumentoHuesped;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_Nacimiento_Huesped")
    @Temporal(TemporalType.DATE)
    private Date fechaNacimientoHuesped;
    @Basic(optional = false)
    @NotNull
    @Column(name = "edad_Huesped")
    private int edadHuesped;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "telefono_Huesped")
    private String telefonoHuesped;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "correo_Huesped")
    private String correoHuesped;

    public Huesped() {
    }

    public Huesped(Integer idHuesped) {
        this.idHuesped = idHuesped;
    }

    public Huesped(Integer idHuesped, String cedulaHuesped, String primerNombreHuesped, String primerApellidoHuesped, String tipoDocumentoHuesped, Date fechaNacimientoHuesped, int edadHuesped, String telefonoHuesped, String correoHuesped) {
        this.idHuesped = idHuesped;
        this.cedulaHuesped = cedulaHuesped;
        this.primerNombreHuesped = primerNombreHuesped;
        this.primerApellidoHuesped = primerApellidoHuesped;
        this.tipoDocumentoHuesped = tipoDocumentoHuesped;
        this.fechaNacimientoHuesped = fechaNacimientoHuesped;
        this.edadHuesped = edadHuesped;
        this.telefonoHuesped = telefonoHuesped;
        this.correoHuesped = correoHuesped;
    }

    public Integer getIdHuesped() {
        return idHuesped;
    }

    public void setIdHuesped(Integer idHuesped) {
        this.idHuesped = idHuesped;
    }

    public String getCedulaHuesped() {
        return cedulaHuesped;
    }

    public void setCedulaHuesped(String cedulaHuesped) {
        this.cedulaHuesped = cedulaHuesped;
    }

    public String getPrimerNombreHuesped() {
        return primerNombreHuesped;
    }

    public void setPrimerNombreHuesped(String primerNombreHuesped) {
        this.primerNombreHuesped = primerNombreHuesped;
    }

    public String getSegundoNombreHuesped() {
        return segundoNombreHuesped;
    }

    public void setSegundoNombreHuesped(String segundoNombreHuesped) {
        this.segundoNombreHuesped = segundoNombreHuesped;
    }

    public String getPrimerApellidoHuesped() {
        return primerApellidoHuesped;
    }

    public void setPrimerApellidoHuesped(String primerApellidoHuesped) {
        this.primerApellidoHuesped = primerApellidoHuesped;
    }

    public String getSegundoApellidoHuesped() {
        return segundoApellidoHuesped;
    }

    public void setSegundoApellidoHuesped(String segundoApellidoHuesped) {
        this.segundoApellidoHuesped = segundoApellidoHuesped;
    }

    public String getTipoDocumentoHuesped() {
        return tipoDocumentoHuesped;
    }

    public void setTipoDocumentoHuesped(String tipoDocumentoHuesped) {
        this.tipoDocumentoHuesped = tipoDocumentoHuesped;
    }

    public Date getFechaNacimientoHuesped() {
        return fechaNacimientoHuesped;
    }

    public void setFechaNacimientoHuesped(Date fechaNacimientoHuesped) {
        this.fechaNacimientoHuesped = fechaNacimientoHuesped;
    }

    public int getEdadHuesped() {
        return edadHuesped;
    }

    public void setEdadHuesped(int edadHuesped) {
        this.edadHuesped = edadHuesped;
    }

    public String getTelefonoHuesped() {
        return telefonoHuesped;
    }

    public void setTelefonoHuesped(String telefonoHuesped) {
        this.telefonoHuesped = telefonoHuesped;
    }

    public String getCorreoHuesped() {
        return correoHuesped;
    }

    public void setCorreoHuesped(String correoHuesped) {
        this.correoHuesped = correoHuesped;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHuesped != null ? idHuesped.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Huesped)) {
            return false;
        }
        Huesped other = (Huesped) object;
        if ((this.idHuesped == null && other.idHuesped != null) || (this.idHuesped != null && !this.idHuesped.equals(other.idHuesped))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.sjreal.entities.Huesped[ idHuesped=" + idHuesped + " ]";
    }
    
}

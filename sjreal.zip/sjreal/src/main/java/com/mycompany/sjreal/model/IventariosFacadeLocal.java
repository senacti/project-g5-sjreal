/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sjreal.model;

import com.mycompany.sjreal.entities.Iventarios;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author usuario
 */
@Local
public interface IventariosFacadeLocal {

    void create(Iventarios iventarios);

    void edit(Iventarios iventarios);

    void remove(Iventarios iventarios);

    Iventarios find(Object id);

    List<Iventarios> findAll();

    List<Iventarios> findRange(int[] range);

    int count();
    
}
